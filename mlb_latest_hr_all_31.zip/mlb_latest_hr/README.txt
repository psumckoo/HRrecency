MLB Most Recent Home Run Finder — All 31 Players
================================================

WHAT IT DOES
Checks all 31 supplied players and exports each player's most recent home run
from the 2026 MLB season. The output includes date, opponent, pitcher, inning,
distance, exit velocity, launch angle, pitch type, pitch speed, MLB game ID,
and MLB player ID.

EASIEST WINDOWS METHOD
1. Install Python from python.org. During installation, check "Add Python to PATH."
2. Extract this ZIP folder.
3. Double-click run_all_players.bat.
4. Leave the window open while it checks the players.

The finished file will be created in the same folder:

   latest_home_runs_2026.csv

COMMAND-LINE METHOD
Open Command Prompt in this folder and run:

   py -m pip install -r requirements.txt
   py latest_home_runs.py

CUSTOM PLAYER LIST
The included players.txt contains all 31 names. To use that file explicitly:

   py latest_home_runs.py --players players.txt --output latest_home_runs_2026.csv

You can replace the names in players.txt with any MLB players, one per line.

NOTES
- Internet access is required.
- The script uses MLB's Stats API to identify players and Baseball Savant
  Statcast data to identify their latest home-run event.
- It pauses 1.5 seconds between players to reduce throttling. If Baseball
  Savant blocks or times out, rerun with a longer pause:

   py latest_home_runs.py --delay 3

- Any failed lookup is preserved in the CSV with an ERROR status, so one bad
  player does not stop the rest of the list.
