#!/usr/bin/env python3
"""Find each player's most recent MLB home run in a season.

Data sources:
- MLB Stats API for player-name resolution
- Baseball Savant Statcast through pybaseball for pitch-level HR details

Usage:
    python latest_home_runs.py
    python latest_home_runs.py --season 2026 --output latest_home_runs.csv
    python latest_home_runs.py --players players.txt
"""
from __future__ import annotations

import argparse
import sys
import time
import unicodedata
from datetime import date
from pathlib import Path

import pandas as pd
import requests
from pybaseball import statcast_batter

DEFAULT_PLAYERS = [
    "Yordan Alvarez",
    "Kyle Schwarber",
    "Hunter Goodman",
    "Ben Rice",
    "Junior Caminero",
    "James Wood",
    "Matt Olson",
    "Byron Buxton",
    "CJ Abrams",
    "Colson Montgomery",
    "Shea Langeliers",
    "Willson Contreras",
    "Dillon Dingler",
    "Manny Machado",
    "Shohei Ohtani",
    "Kazuma Okamoto",
    "Jordan Walker",
    "Pete Alonso",
    "Pete Crow-Armstrong",
    "Luis García Jr.",
    "Bryce Harper",
    "Brandon Lowe",
    "Juan Soto",
    "Sal Stewart",
    "Miguel Vargas",
    "Rafael Devers",
    "Nick Kurtz",
    "Max Muncy",
    "Munetaka Murakami",
    "Casey Schmitt",
    "Christian Walker",
]

MLB_SEARCH_URL = "https://statsapi.mlb.com/api/v1/people/search"
REQUEST_TIMEOUT = 30


def normalize(text: str) -> str:
    text = unicodedata.normalize("NFKD", text)
    return "".join(ch for ch in text if not unicodedata.combining(ch)).casefold().strip()


def resolve_mlbam_id(player_name: str, session: requests.Session) -> tuple[int, str]:
    """Resolve a player name to an MLBAM ID using MLB's Stats API."""
    response = session.get(
        MLB_SEARCH_URL,
        params={"names": player_name, "sportIds": 1, "hydrate": "currentTeam"},
        timeout=REQUEST_TIMEOUT,
    )
    response.raise_for_status()
    people = response.json().get("people", [])
    if not people:
        raise LookupError(f"No MLB player found for {player_name!r}")

    wanted = normalize(player_name)
    exact = [p for p in people if normalize(p.get("fullName", "")) == wanted]
    candidates = exact or people
    candidates.sort(key=lambda p: (not p.get("active", False), p.get("id", 10**9)))
    person = candidates[0]
    return int(person["id"]), person.get("fullName", player_name)


def latest_hr_for_player(player_name: str, season: int, session: requests.Session) -> dict:
    player_id, official_name = resolve_mlbam_id(player_name, session)
    start_date = f"{season}-03-01"
    season_end = date(season, 12, 31)
    end_date_obj = min(date.today(), season_end)
    if end_date_obj < date(season, 3, 1):
        raise ValueError(f"The {season} season has not begun yet")
    end_date = end_date_obj.isoformat()

    pitches = statcast_batter(start_date, end_date, player_id)
    if pitches is None or pitches.empty:
        return {"player": official_name, "mlbam_id": player_id, "status": "No Statcast data found"}

    home_runs = pitches[pitches["events"].eq("home_run")].copy()
    if home_runs.empty:
        return {
            "player": official_name,
            "mlbam_id": player_id,
            "status": f"No home runs found in {season}",
        }

    sort_columns = [
        c for c in ["game_date", "game_pk", "at_bat_number", "pitch_number"]
        if c in home_runs.columns
    ]
    latest = home_runs.sort_values(sort_columns, ascending=False).iloc[0]

    def value(column: str):
        val = latest.get(column)
        return None if pd.isna(val) else val

    game_date = pd.to_datetime(value("game_date")).date().isoformat()
    inning = value("inning")
    inning_half = value("inning_topbot")
    inning_text = f"{inning_half} {int(inning)}" if inning is not None and inning_half else None
    opponent = value("home_team") if inning_half == "Top" else value("away_team")

    return {
        "player": official_name,
        "mlbam_id": player_id,
        "date": game_date,
        "opponent": opponent,
        "pitcher": value("player_name"),
        "inning": inning_text,
        "distance_ft": value("hit_distance_sc"),
        "exit_velocity_mph": value("launch_speed"),
        "launch_angle_deg": value("launch_angle"),
        "pitch_type": value("pitch_type"),
        "pitch_speed_mph": value("release_speed"),
        "game_pk": int(value("game_pk")) if value("game_pk") is not None else None,
        "status": "OK",
    }


def load_players(path: str | None) -> list[str]:
    if not path:
        return DEFAULT_PLAYERS
    lines = Path(path).read_text(encoding="utf-8").splitlines()
    players = [line.strip() for line in lines if line.strip() and not line.lstrip().startswith("#")]
    if not players:
        raise ValueError("Player file contains no names")
    return players


def main() -> int:
    parser = argparse.ArgumentParser(description="Find the most recent HR for each MLB player.")
    parser.add_argument("--season", type=int, default=2026)
    parser.add_argument("--players", help="Text file with one player name per line")
    parser.add_argument("--output", default="latest_home_runs_2026.csv")
    parser.add_argument("--delay", type=float, default=1.5, help="Seconds between players")
    args = parser.parse_args()

    try:
        players = load_players(args.players)
    except Exception as exc:
        print(f"Could not load players: {exc}", file=sys.stderr)
        return 2

    session = requests.Session()
    session.headers.update({"User-Agent": "MLB-latest-home-run-script/2.0"})
    rows: list[dict] = []

    for index, player in enumerate(players, start=1):
        print(f"[{index}/{len(players)}] Checking {player}...", flush=True)
        try:
            rows.append(latest_hr_for_player(player, args.season, session))
        except Exception as exc:
            rows.append({"player": player, "status": f"ERROR: {exc}"})
        if index < len(players):
            time.sleep(max(args.delay, 0))

    result = pd.DataFrame(rows)
    preferred = [
        "player", "date", "opponent", "pitcher", "inning", "distance_ft",
        "exit_velocity_mph", "launch_angle_deg", "pitch_type", "pitch_speed_mph",
        "game_pk", "mlbam_id", "status",
    ]
    result = result.reindex(columns=[c for c in preferred if c in result.columns])
    result.to_csv(args.output, index=False)

    with pd.option_context("display.max_columns", None, "display.width", 180):
        print("\n" + result.to_string(index=False))
    print(f"\nSaved: {Path(args.output).resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
