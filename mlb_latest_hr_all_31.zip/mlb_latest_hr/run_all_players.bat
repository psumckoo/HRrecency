@echo off
py -m pip install -r requirements.txt
if errorlevel 1 pause & exit /b 1
py latest_home_runs.py
pause
